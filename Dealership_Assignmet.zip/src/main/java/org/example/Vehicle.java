package org.example;

public class Vehicle implements VehicleInterface, Comparable<Vehicle> {
    public enum FuelType {
        PETROL, DIESEL, HYBRID
    }

    protected String brand;
    protected String model;
    protected double basePrice;
    protected int age;
    protected double km;
    protected FuelType fuelType;

    public Vehicle(String brandString, double basePrice, int age, double km, FuelType fuelType) {
        String[] parts = brandString.split(" ", 2);
        this.brand = parts[0];
        this.model = parts.length > 1 ? parts[1] : "";
        this.basePrice = basePrice;
        this.age = age;
        this.km = km;
        this.fuelType = fuelType;
    }

    @Override
    public void applyDiscount(int percentage) {
        this.basePrice -= this.basePrice * (percentage / 100.0);
    }

    @Override
    public int getFinalPrice() {
        double price = basePrice - (age * 150000);
        if (price < 200000) {
            price = 200000;
        }

        if (fuelType == FuelType.HYBRID) {
            price *= 1.15; // +15%
        } else if (fuelType == FuelType.DIESEL) {
            price *= 1.05; // +5%
        }

        return (int) price;
    }

    @Override
    public double averageKmPerYear() {
        if (age == 0) {
            return km;
        }
        return km / age;
    }

    @Override
    public int compareTo(Vehicle other) {
        return Integer.compare(this.getFinalPrice(), other.getFinalPrice());
    }

    @Override
    public String toString() {
        return String.format("%s %s | Price: %d | Avg km/year: %.2f | Age: %d | Fuel: %s",
                brand, model, getFinalPrice(), averageKmPerYear(), age, fuelType);
    }

    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public double getBasePrice() { return basePrice; }
    public int getAge() { return age; }
    public double getKm() { return km; }
    public FuelType getFuelType() { return fuelType; }
}