package org.example;

public class ElectricVehicle extends Vehicle implements ElectricInterface {
    private int batteryCapacity;
    private boolean hasHeatPump;

    public ElectricVehicle(String brandString, double basePrice, int age, double km, FuelType fuelType, int batteryCapacity, boolean hasHeatPump) {
        super(brandString, basePrice, age, km, fuelType);
        this.batteryCapacity = batteryCapacity;
        this.hasHeatPump = hasHeatPump;
    }

    @Override
    public int getFinalPrice() {
        int baseCalculatedPrice = super.getFinalPrice();
        double finalPrice = baseCalculatedPrice;

        if (batteryCapacity >= 60) {
            finalPrice *= 1.10;
        }

        if (hasHeatPump) {
            finalPrice *= 1.05;
        }

        return (int) finalPrice;
    }

    @Override
    public boolean hasSameRangeCategory(Vehicle other) {
        if (other instanceof ElectricVehicle) {
            ElectricVehicle otherElectric = (ElectricVehicle) other;
            return Math.abs(this.batteryCapacity - otherElectric.batteryCapacity) <= 5;
        }
        return false;
    }

    @Override
    public int batteryCostShare() {
        return batteryCapacity * 25000;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Battery: %d kWh | Heat Pump: %s",
                batteryCapacity, hasHeatPump ? "Yes" : "No");
    }

    public int getBatteryCapacity() { return batteryCapacity; }
}